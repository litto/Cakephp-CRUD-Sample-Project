<?php
App::uses('AppModel', 'Model');

class Admin extends  AppModel{
	public $name		=	'Admin';
	public $useTable	=	'cms_admin';
	public $primaryKey	=	'auth_id';
	function adminuser(){
		$rec	=	$this->find('all',array('conditions'=>array('Admin.auth_id'=>1)));
		return $rec;
	}
	function admininfo(){
		$rec	=	$this->find('all');
		return $rec;
	}	
}
?>