<?php
class Post extends AppModel {
}

?>