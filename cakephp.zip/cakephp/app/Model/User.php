<?php
App::uses('AppModel', 'Model');

class User extends  AppModel{
	public $name		=	'User';
	public $useTable	=	'cms_userauth';
	public $primaryKey	=	'user_id';
	function getuser(){
		$rec	=	$this->find('all',array('conditions'=>array('Admin.status'=>1)));
		return $rec;
	}
	function admininfo(){
		$rec	=	$this->find('all');
		return $rec;
	}	
}
?>