<?php


class Flash extends AppModel{
	public $name='Flash';
	public $useTable	=	false;
	public $messageText='';
	public $messageType='';
	public $session=null;
	
	/*
	 * Set Flash Message
	*/
	public function set($type,$text){
		
		$this->Session->write('messageText',$text);
		$this->Session->write('messageType',$type);
		$messageText=$text;
		$messageType=$type;
	}
	
	/*
	 * Function Get Flash Message
	*/
	public function get(){		
		$session	=	$this->Session->read();	
		if(!isset($session['messageType'])){
			$session['messageType']=null;
		}
		switch($session['messageType']){
			case 'error';				
				$this->Session->write('messageText','');
				$this->Session->write('messageType','');
				return '<div class="alert alert-danger">'.$session['messageText'].'</div>';
				break;
			case 'success';				
				$this->Session->write('messageText','');
				$this->Session->write('messageType','');
				return '<div class="alert alert-success">'.$session['messageText'].'</div>';
				break;
				
			case 'warning';				
				$this->Session->write('messageText','');
				$this->Session->write('messageType','');
				return '<div class="alert alert-warning">'.$session['messageText'].'</div>';
				break;
				
			case 'notice';				
				$this->Session->write('messageText','');
				$this->Session->write('messageType','');
				return '<div class="alert alert-primary">'.$session['messageText'].'</div>';
				break;
			
			default:
				return '';
				break;
		}
		
	}
	
	
}

?>