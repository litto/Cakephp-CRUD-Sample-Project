<?php
App::uses('AppController', 'Controller');
class AdminController extends AppController{
	public $helpers 	= 	array('Html', 'Form','Session');
	public $uses		=	array('Admin','Flash','SessionManager');
	public $components	=	array('Session');



	function init(){
		$this->Flash->Session=$this->Session;
		$this->SessionManager->Session=$this->Session;
	}

	function index(){
	
	    $this->layout	=	'admin/index';
    	$this->init();
		// $flashMessage=$this->Flash->get();
		// $this->set('flash',$flashMessage);

	if ($this->request->is('post')) {

		    $result 	= 	$this->request->data;	
	        $name		=	$result['email'];	
			$pass		=	$result['password'];						
			$Uname		=	trim(strip_tags($name));
			$Upass		=	trim(strip_tags($pass));

			if(empty($Uname) || empty($Upass)){

				$userMessage='Enter username and password';
				$this->Flash->set($userMessage);
			}
			else
			{
               $args		=	array('conditions'=>array('Admin.UserName'=>$Uname,'Admin.Password'=>$Upass));
				$data		=	$this->Admin->find('all',$args);

                 if(count($data)>0){ 
                    $userMessage	=	'Successfully Loggedin';
					$authId		=	$data[0]['Admin']['auth_id'];
					$username	=	$data[0]['Admin']['username'];
					$email	=	$data[0]['Admin']['email'];					
		
					$this->Session->write('Admin.authAdminId',base64_encode($authId));
					$this->Session->write('Admin.authAdminName',base64_encode($username));
					$this->Session->write('Admin.authAdminEmail',base64_encode($email));
					$this->Session->write('Admin.logged_in','true');	
                    $save = array('date_login'=>date('Y-m-d H:i:s'),'login_ip'=>$_SERVER['REMOTE_ADDR']);
					$this->Admin->set($save);
					$this->Admin->id=$authId;
					$this->Admin->save();
                    $this->Flash->set($userMessage);
                    $this->redirect('/admin/home/');  
                   }else{
					$userMessage='Invalid username or password given !';
					$this->Flash->set($userMessage);
				}  

			}	

   }
}


function home(){

	$this->layout	=	'admin/hdftlayout';




}

	function logout(){	
	$this->Session->destroy();
	//return $this->redirect(array('action' => 'index'));	
	$this->redirect('/admin/index/');
	}



}

?>