<?php
App::uses('AppController', 'Controller');
class UserController extends AppController{
	public $helpers 	= 	array('Html', 'Form','Session');
	public $uses		=	array('Admin','Flash','User','SessionManager','Uploader');
	public $components	=	array('Session','Paginator');



	public function init(){
		$this->Flash->Session=$this->Session;
		$this->SessionManager->Session=$this->Session;
	}


public function admin_list(){

	$this->layout	=	'admin/hdftlayout';
    $this->init();
	$userlist 		=	$this->User->find('all');
	$this->set('userlist',$userlist);	


}

public function admin_add(){

	$this->layout	=	'admin/hdftlayout';
    $this->init();

    if ($this->request->is('post')) {
		$result 	= 	$this->request->data;
		$sname		=	$result['sname'];	
        $semail		=	$result['semail'];

                        $mediaBaseDir	=	Configure::read('MediaDir');//Media Base Directory//
						if (!is_dir($mediaBaseDir.'user')){
							mkdir($mediaBaseDir.'user');
							chmod($mediaBaseDir.'user',0777);
						}
						$mediaPath		=	$mediaBaseDir.'user'.'/';
						$this->Uploader->setDir($mediaPath);
						$this->Uploader->setExtensions(array('jpg','jpeg','png','gif'));
						$this->Uploader->setMaxSize(8);
						$this->Uploader->setSequence('user'); 
						$filename		=	'txtImg';


			if($this->Uploader->uploadFile($filename)){	//upload success	
							$image	=	$this->Uploader->getUploadName();

						}else{
							$image='user.png';
						}	
							$save	=	array('name'=>$sname,'email'=>$semail,'photo'=>$image,'status'=>'1');
							$this->User->set($save);
							if($this->User->save()){
								$lastId			=	$this->User->getLastInsertID();
								  $userMessage	=	'Record Successfully Created!!';
							   $this->Flash->set($userMessage);
                           $this->redirect('/admin/user/list/');  
						 	}
							
	}
	


}



public function admin_edit(){

$this->layout	=	'admin/hdftlayout';
$this->init();
$query				=	$this->request->pass;
$id=$query[0];
$record			=	$this->User->find('all',array(
		'conditions' => array('User.user_id' => $id)
	    	));	
$this->set('record',$record);
$this->set('id',$id);
   if ($this->request->is('post')) {
		$result 	= 	$this->request->data;

        $sname		=	$result['sname'];	
        $semail		=	$result['semail'];
        $id= $result['id'];

                        $mediaBaseDir	=	Configure::read('MediaDir');//Media Base Directory//
						if (!is_dir($mediaBaseDir.'user')){
							mkdir($mediaBaseDir.'user');
							chmod($mediaBaseDir.'user',0777);
						}
						$mediaPath		=	$mediaBaseDir.'user'.'/';
						$this->Uploader->setDir($mediaPath);
						$this->Uploader->setExtensions(array('jpg','jpeg','png','gif'));
						$this->Uploader->setMaxSize(8);
						$this->Uploader->setSequence('user'); 
						$filename		=	'txtImg';


			if($this->Uploader->uploadFile($filename)){	//upload success	
							$image	=	$this->Uploader->getUploadName();
	                        $save	=	array('name'=>$sname,'email'=>$semail,'photo'=>$image);
							$this->User->id=$id;
							$this->User->set($save);
							$this->User->save();
						}else{
							$image='user.png';
							$save	=	array('name'=>$sname,'email'=>$semail);
							$this->User->id=$id;
							$this->User->set($save);
							$this->User->save();
						}

							  $userMessage	=	'Record Edited Successfully!!';
							   $this->Flash->set($userMessage);
                           $this->redirect('/admin/user/list/');  

	}




}


	public function admin_delete(){	
		$this->autoRender 	= 	false ;
		$val			=	$this->request->query['val'];		
		$res 			=	$this->User->delete($val);
		if($res==1){
		$err 			= 	'<div class="alert alert-success"> Data  Successfully Deleted!..</div>';
		}else{
		$err 			=	'<div class="alert alert-danger">Error in Deleting Data !..</div>';
		}
		}



}

 ?>